from flask_jwt_extended import JWTManager

jwt = JWTManager()