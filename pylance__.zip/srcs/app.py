from flask import Flask, request, jsonify
from config import app_config
from apscheduler.schedulers.background import BackgroundScheduler
from services.apigee_token import get_acess_token, get_secret_token
from services import common, health_check
import sys
import traceback
import json
from extensions import jwt
from datetime import timedelta
from pytz import timezone
from flask_wtf import CSRFProtect
import urllib3

urllib3.disable_warnings()


# set configration on the basis of argument

if (len(sys.argv) == 2) and (sys.argv[1].lower() in ['dev', 'sit', 'qa', 'prod', 'demo']):
    # declare env variable as global
    app_config.init_env_declare(env_var=sys.argv[1])
    RUNTIME = sys.argv[1]
    print ('Runtime', RUNTIME)
else:
    print("Environment argument is not passed!!!")
    app_config.init_env_declare(env_var="sit")
    RUNTIME = "sit"
    print ('Runtime 1', RUNTIME)

app_config.init_conf()
APP_NAME = app_config.cfg['App']['app_name']

APP_NAME = app_config.cfg['App']['app_name']
DEV_SECRET = app_config.cfg['error_handling']['dev_secret']
PROJECT_NAME = app_config.cfg['services']['project_id']
TIMEZONE = app_config.cfg['timezone_settings']['timezone']
TIME_FORMAT = app_config.cfg['timezone_settings']['time_format']
TZ = timezone(TIMEZONE)
DATABASE = app_config.cfg['database']['database_name']
STORAGE_BUCKET = app_config.cfg['storage']['storage_bucket_name']
SFV_SQL_URL = app_config.cfg['api']['sfv_sql_base_url']
SFV_STORAGE_URL = app_config.cfg['api']['sfv_storage_base_url']
SFV_LOGGER_URL = app_config.cfg['logging']['logger_url']
SFV_URL_VERIFY = True if RUNTIME != 'sit' else False
SFV_SECRET_MANAGER_URL = app_config.cfg['api']['sfv_gcp_sm']
SENDER_NAME = app_config.cfg['email']['sender_name']
SENDER_EMAIL = app_config.cfg['email']['sender_email']
CFI_EMAIL = app_config.cfg['email']['cfi_email']
LOG = json.loads(app_config.cfg['logs']['log_code'])
ERROR = json.loads(app_config.cfg['logs']['error_code'])
APPLICATION_URL = app_config.cfg['application_url']['application_url']
CORRELATION_ID = app_config.cfg['App']['correlation_id']
APP_USER_EMAIL = app_config.cfg['App']['app_user_email']
APP_USER_NAME = app_config.cfg['App']['app_user_name']
JWT_SECRET_KEY = get_secret_token("sfty-cocreateai-jwt-secret")



app = Flask(APP_NAME)
app.config['SECRET_KEY'] = JWT_SECRET_KEY
# csrf = CSRFProtect()
# csrf.init_app(app)
app.config['MAX_CONTENT_LENGTH'] = int(app_config.cfg['services']['max_content_length'])

app.config['JWT_SECRET_KEY'] = JWT_SECRET_KEY
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=int(app_config.cfg['jwt']['access_token_expiry']))
app.config["JWT_REFRESH_TOKEN_EXPIRES"] = timedelta(days=int(app_config.cfg['jwt']['refresh_token_expiry']))
app.config.from_prefixed_env()
jwt.init_app(app)


@app.errorhandler(500)
def internal_error(e):
  return e.description, 500


@app.errorhandler(404)
def resource_not_found(e):
  return jsonify(error=str(e)), 404


@app.errorhandler(400)
def resource_not_found(e):
  return jsonify(error=str(e)), 400






from routes.admin.roles import roles_bp
from routes.admin.user import user_bp
from routes.admin.reports import admin_reports_bp
from routes.admin.section_group_leader import admin_sgl_bp
from routes.auth import auth_bp
from routes.products import products_bp
from routes.template import template_bp
from routes.common import common_bp



@app.route("/", methods=['GET'])
@app.route("/site-map", methods=['GET'])
def ep_sitemap():
  dev_secret = None
  try:
    response = common.update_response_metadata(ep_links)
    return response, 200
  except Exception as ex:
    traceback_error = traceback.format_exc(chain=False)
    common.process_exception(ex, traceback_error, dev_secret)

@app.route("/api/health", methods=['GET'])
def ep_health_check():
  dev_secret = None
  try:
    response = health_check.main()
    response = common.update_response_metadata(response)
    return response, 200
  except Exception as ex:
    traceback_error = traceback.format_exc(chain=False)
    common.process_exception(ex, traceback_error, dev_secret)


sched = BackgroundScheduler()

 ## Scheduler to set the apigee token in the enviroment
 # on app startup fist set the enviroment for token



USERNAME = get_secret_token('sfty-cocreateai-apigee-clientid')
PASSWORD =get_secret_token('sfty-cocreateai-apigee-secret')
@jwt.expired_token_loader
def expired_token_callback(jwt_header, jwt_data):
  print("expired token")

  return jsonify({
    "message": "Token has expired",
    "error": "token_expired"
  }), 401

@jwt.invalid_token_loader
def invalid_token_callback(error):
  print("invalid token", request.headers)

  return jsonify({
    "message": "Signature varification failed",
    "error": "invalid_token"
  }), 401

@jwt.unauthorized_loader
def missing_token_callback(error):
  print("request--------------",request.headers)
  print("missing_token_callback error---------",error)
  return jsonify({
    "message": "Request doesn't contain valid token",
    "error": "authorization_header"
  }), 401

@app.before_request
def test():
  print("@@@@@@@@@@@@@@@@",request.headers)
get_acess_token()


app.register_blueprint(roles_bp)
app.register_blueprint(user_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(admin_reports_bp)
app.register_blueprint(products_bp)
app.register_blueprint(template_bp)
app.register_blueprint(common_bp)
app.register_blueprint(admin_sgl_bp)




sched.add_job(get_acess_token, trigger='interval', minutes=20)



if __name__ == "__main__":
    sched.start()
    ep_links = []
    for rule in app.url_map.iter_rules():
        ep_dict = {"endpoint": rule.rule, "Method": str(rule.methods)}
        ep_links.append(ep_dict)
    app.run(host = app_config.cfg['App']['host'],
            port = app_config.cfg['App']['port'],
            debug = app_config.cfg['App']['debug'])
